import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Screen settings
screen_width = 500
screen_height = 500
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("AERO")
clock = pygame.time.Clock()

# Variables
plane_x = screen_width // 2
plane_y = screen_height // 2
score = 0
health = 100
obstacles = []
game_over = False

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GRAY = (192, 192, 192)
DARK_GRAY = (96, 96, 96)
BLUE = (0, 0, 255)

# Fonts
font = pygame.font.Font(None, 36)
large_font = pygame.font.Font(None, 72)

# Load sounds
pygame.mixer.music.load(r'C:\Users\mayur\Downloads\WhatsApp Unknown 2024-07-26 at 08.00.50\WhatsApp Audio 2024-07-26 at 01.35.16.mpeg')  # Replace with your background music file
pygame.mixer.music.play(-1)  # Play the background music in a loop
move_sound = pygame.mixer.Sound(r'C:\Users\mayur\Downloads\WhatsApp Audio 2024-07-26 at 08.41.11.mpeg')  # Replace with your move sound file
crash_sound = pygame.mixer.Sound(r'C:\Users\mayur\Downloads\WhatsApp Audio 2024-07-26 at 08.13.02.mpeg')  # Replace with your crash sound file

def draw_plane(x, y):
    pygame.draw.polygon(screen, WHITE, [(x, y+30), (x, y+55), (x+135, y+55), (x+135, y+30)])
    pygame.draw.polygon(screen, WHITE, [(x+135, y+55), (x+150, y+50), (x+155, y+45), (x+160, y+40), (x+135, y+40)])
    pygame.draw.polygon(screen, BLACK, [(x+135, y+55), (x+150, y+50), (x+155, y+45), (x+160, y+40), (x+135, y+40)], 1)
    pygame.draw.polygon(screen, RED, [(x+135, y+40), (x+160, y+40), (x+160, y+37), (x+145, y+30), (x+135, y+30)])
    pygame.draw.polygon(screen, RED, [(x, y), (x, y+50), (x+10, y+40), (x, y)])
    pygame.draw.polygon(screen, RED, [(x+65, y+55), (x+50, y+70), (x+75, y+70), (x+90, y+55)])
    pygame.draw.polygon(screen, RED, [(x+70, y+40), (x+100, y+40), (x+80, y+15), (x+50, y+15)])

def spawn_obstacle():
    obstacle_x = screen_width
    obstacle_y = random.randint(100, screen_height - 100)
    return {'x': obstacle_x, 'y': obstacle_y, 'width': 50, 'height': 50}

def draw_obstacles():
    for obstacle in obstacles:
        pygame.draw.rect(screen, RED, (obstacle['x'], obstacle['y'], obstacle['width'], obstacle['height']))

def update_obstacles():
    global score, health, game_over
    for obstacle in obstacles:
        obstacle['x'] -= 10
        if obstacle['x'] < -50:
            obstacles.remove(obstacle)
            score += 10
        if plane_x + 135 > obstacle['x'] and plane_x < obstacle['x'] + obstacle['width']:
            if plane_y + 55 > obstacle['y'] and plane_y < obstacle['y'] + obstacle['height']:
                health -= 10
                crash_sound.play()  # Play crash sound
                obstacles.remove(obstacle)
    if health <= 0:
        health = 0
        game_over = True

def display():
    screen.fill(BLUE)
    draw_plane(plane_x, plane_y)
    draw_obstacles()
    score_text = font.render(f"Score: {score}", True, WHITE)
    health_text = font.render(f"Health: {health}%", True, WHITE)
    screen.blit(score_text, (10, 10))
    screen.blit(health_text, (10, 50))
    if game_over:
        display_game_over()
    pygame.display.flip()

def display_game_over():
    game_over_text = large_font.render("GAME OVER", True, RED)
    game_over_rect = game_over_text.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
    screen.blit(game_over_text, game_over_rect)
    restart_text = font.render("Press R to Restart", True, WHITE)
    restart_rect = restart_text.get_rect(center=(screen_width // 2, screen_height // 2 + 20))
    screen.blit(restart_text, restart_rect)
    quit_text = font.render("Press Q to Quit", True, WHITE)
    quit_rect = quit_text.get_rect(center=(screen_width // 2, screen_height // 2 + 60))
    screen.blit(quit_text, quit_rect)

def reset_game():
    global plane_x, plane_y, score, health, obstacles, game_over
    plane_x = screen_width // 2
    plane_y = screen_height // 2
    score = 0
    health = 100
    obstacles = []
    game_over = False

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if game_over:
                if event.key == pygame.K_r:
                    reset_game()
                elif event.key == pygame.K_q:
                    running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        plane_x -= 10
        move_sound.play()
    if keys[pygame.K_RIGHT]:
        plane_x += 10
        move_sound.play()
    if keys[pygame.K_UP]:
        plane_y -= 10
        move_sound.play()
    if keys[pygame.K_DOWN]:
        plane_y += 10
        move_sound.play()

    plane_x = max(0, min(plane_x, screen_width - 135))
    plane_y = max(0, min(plane_y, screen_height - 55))

    if not game_over:
        if random.randint(0, 100) < 2:
            obstacles.append(spawn_obstacle())
        update_obstacles()

    display()
    clock.tick(30)

pygame.quit()
sys.exit()
