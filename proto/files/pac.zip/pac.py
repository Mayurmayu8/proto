import pygame
import random

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PACMAN_RADIUS = 20
PACMAN_SPEED = 5
GHOST_SPEED = 5
PELLET_width = 1
PELLET_height = 1

GRID_SIZE = 20

# Colors
GREEN = (0 , 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)

# Initialize Pygame
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Pacman Game')
font = pygame.font.SysFont('Arial', 24)

# Load background music
pygame.mixer.music.load(r"C:\Users\mayur\Downloads\Pac-Man ringtone (320).mp3")

def play_background_music():
    pygame.mixer.music.play(-1)  # Loop the music indefinitely

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = PACMAN_RADIUS
        self.color = BLUE
        self.direction = [1, 0]

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.direction = [-1, 0]
        elif keys[pygame.K_RIGHT]:
            self.direction = [1, 0]
        elif keys[pygame.K_UP]:
            self.direction = [0, -1]
        elif keys[pygame.K_DOWN]:
            self.direction = [0, 1]

        self.x += self.direction[0] * PACMAN_SPEED
        self.y += self.direction[1] * PACMAN_SPEED
        self.x = max(self.radius, min(SCREEN_WIDTH - self.radius, self.x))
        self.y = max(self.radius, min(SCREEN_HEIGHT - self.radius, self.y))

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)

class Ghost:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = PACMAN_RADIUS
        self.color = RED
        self.direction = [random.choice([-1, 1]), random.choice([-1, 1])]

    def update(self):
        self.x += self.direction[0] * GHOST_SPEED
        self.y += self.direction[1] * GHOST_SPEED
        if self.x <= self.radius or self.x >= SCREEN_WIDTH - self.radius:
            self.direction[0] = -self.direction[0]
        if self.y <= self.radius or self.y >= SCREEN_HEIGHT - self.radius:
            self.direction[1] = -self.direction[1]

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)

class Pellet:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = PELLET_width
        self.height = PELLET_height
        self.color = WHITE

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.width,self.height)

class Button:
    def __init__(self, x, y, width, height, text, color, hover_color):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color

    def draw(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(mouse_pos):
            pygame.draw.rect(screen, self.hover_color, self.rect)
        else:
            pygame.draw.rect(screen, self.color, self.rect)
        
        text_surface = font.render(self.text, True, BLACK)
        screen.blit(text_surface, (
            self.rect.x + (self.rect.width - text_surface.get_width()) / 2,
            self.rect.y + (self.rect.height - text_surface.get_height()) / 2
        ))

    def is_clicked(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                return True
        return False

def init_pellets():
    pellets = []
    for i in range(GRID_SIZE // 2, SCREEN_WIDTH, GRID_SIZE):
        for j in range(GRID_SIZE // 2, SCREEN_HEIGHT, GRID_SIZE):
            pellets.append(Pellet(i, j))
    return pellets

def draw_text(text, position, color):
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, position)

def game_loop():
    player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
    ghosts = [Ghost(random.randint(50, SCREEN_WIDTH - 50), random.randint(50, SCREEN_HEIGHT - 50)) for _ in range(4)]
    pellets = init_pellets()
    quit_button = Button(SCREEN_WIDTH - 100, 10, 80, 30, 'Quit', BLUE, RED)

    running = True
    score = 0
    game_over = False
    win = False

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if quit_button.is_clicked(event):
                running = False

        if not game_over:
            player.update()
            for ghost in ghosts:
                ghost.update()

            screen.fill(BLACK)
            player.draw()
            for ghost in ghosts:
                ghost.draw()
            for pellet in pellets:
                pellet.draw()
            quit_button.draw()

            # Check pellet collision
            for pellet in pellets[:]:
                if (player.x - pellet.x) ** 2 + (player.y - pellet.y) ** 2 < (player.radius + pellet.width) ** 2 +  (player.radius + pellet.height):
                    pellets.remove(pellet)
                    score += 10

            # Check ghost collision
            for ghost in ghosts:
                if (player.x - ghost.x) ** 2 + (player.y - ghost.y) ** 2 < (player.radius + ghost.radius) ** 2:
                    game_over = True
                    pygame.mixer.music.stop()  # Stop the music

            # Check if all pellets are collected
            if not pellets:
                game_over = True
                win = True

            draw_text(f'Score: {score}', (10, 10), WHITE)
        else:
            screen.fill(BLACK)
            if win:
                draw_text('You Win!', (SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2), WHITE)
            else:
                draw_text('Game Over', (SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2), RED)

            draw_text(f'Final Score: {score}', (SCREEN_WIDTH // 2 - 70, SCREEN_HEIGHT // 2 - 30), WHITE)
            draw_text('Press R to Restart', (SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT // 2 - 60), WHITE)
            quit_button.draw()

            keys = pygame.key.get_pressed()
            if keys[pygame.K_r]:
                play_background_music()  # Restart music
                game_loop()  # Restart the game

        pygame.display.flip()
        pygame.time.Clock().tick(60)

def main():
    play_background_music()  # Start music
    game_loop()
    pygame.quit()

if __name__ == "__main__":
    main()
